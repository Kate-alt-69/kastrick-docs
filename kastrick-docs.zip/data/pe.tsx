/* ========================================================================== */
/*                            ProductExplorer (PE)                            */
/*                         Part 1 — Foundation/Layout                         */
/* ========================================================================== */

"use client";

import React from "react";

/* -------------------------------------------------------------------------- */
/* Types                                                                      */
/* -------------------------------------------------------------------------- */

export interface ProductExplorerProps {
	title?: string;
	description?: string;

	children?: React.ReactNode;

	showExplorer?: boolean;
	showOutline?: boolean;
	showHeader?: boolean;
	showFooter?: boolean;

	explorerWidth?: number;
	outlineWidth?: number;
}

export interface ProductExplorerMetadata {
	title: string;

	description?: string;

	icon?: string;

	badge?: string;

	order?: number;

	author?: {
		name: string;
		avatar?: string;
		organization?: string;
	};

	version?: string;

	status?:
		| "stable"
		| "beta"
		| "alpha"
		| "deprecated";

	updated?: string;
	created?: string;
}

/* -------------------------------------------------------------------------- */
/* Default Props                                                              */
/* -------------------------------------------------------------------------- */

const DEFAULT_PROPS: Required<
	Omit<ProductExplorerProps, "children">
> = {
	title: "",

	description: "",

	showExplorer: true,

	showOutline: true,

	showHeader: true,

	showFooter: true,

	explorerWidth: 310,

	outlineWidth: 300,
};

/* -------------------------------------------------------------------------- */
/* Placeholder Components                                                     */
/* -------------------------------------------------------------------------- */

function OutlinePane() {
	return (
		<aside className="pe-outline">
			Outline
		</aside>
	);
}

function FooterPane() {
	return (
		<footer className="pe-footer">
			Footer
		</footer>
	);
}

/* -------------------------------------------------------------------------- */
/* Main Component                                                             */
/* -------------------------------------------------------------------------- */

export default function ProductExplorer(
	props: ProductExplorerProps,
) {
	const settings = {
		...DEFAULT_PROPS,
		...props,
	};

	return (
		<div
			className="pe-root"
			style={
				{
					"--pe-left":
						`${settings.explorerWidth}px`,

					"--pe-right":
						`${settings.outlineWidth}px`,
				} as React.CSSProperties
			}
		>
			{settings.showExplorer && (
				<ExplorerPane />
			)}

			<div className="pe-content">
				{settings.showHeader && (
					<HeaderPane
						title={settings.title}
						description={
							settings.description
						}
					/>
				)}

				<main className="pe-document">
					{settings.children}
				</main>

				{settings.showFooter && (
					<FooterPane />
				)}
			</div>

			{settings.showOutline && (
				<OutlinePane />
			)}
		</div>
	);
}

/* -------------------------------------------------------------------------- */
/* Layout CSS                                                                 */
/* -------------------------------------------------------------------------- */

const style = `
.pe-root{

	display:grid;

	grid-template-columns:
		var(--pe-left)
		minmax(0,1fr)
		var(--pe-right);

	min-height:100vh;

	background:var(--e-bg,#070b12);

	color:white;
}

.pe-explorer{

	position:sticky;

	top:0;

	height:100vh;

	overflow:auto;

	border-right:1px solid rgba(255,255,255,.06);

	padding:2rem;
}

.pe-content{

	min-width:0;

	display:flex;

	flex-direction:column;
}

.pe-header{

	padding:
		2.5rem
		3rem
		2rem;

	border-bottom:
		1px solid rgba(255,255,255,.05);
}

.pe-document{

	flex:1;

	padding:3rem;

	max-width:1100px;

	width:100%;
}

.pe-outline{

	position:sticky;

	top:0;

	height:100vh;

	overflow:auto;

	padding:2rem;

	border-left:
		1px solid rgba(255,255,255,.06);
}

.pe-footer{

	padding:2rem 3rem;

	border-top:
		1px solid rgba(255,255,255,.05);
}

@media(max-width:1200px){

	.pe-root{

		grid-template-columns:
			280px
			minmax(0,1fr);
	}

	.pe-outline{

		display:none;
	}
}

@media(max-width:900px){

	.pe-root{

		grid-template-columns:1fr;
	}

	.pe-explorer{

		display:none;
	}

	.pe-header{

		padding:2rem;
	}

	.pe-document{

		padding:2rem;
	}
}
`;

if (typeof document !== "undefined") {
	if (!document.getElementById("pe-layout-style")) {
		const css = document.createElement("style");

		css.id = "pe-layout-style";

		css.innerHTML = style;

		document.head.appendChild(css);
	}
}

/* ========================================================================== */
/*                      Part 2 — Discovery Engine Types                       */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/* Explorer Tree                                                              */
/* -------------------------------------------------------------------------- */

export type PENodeType =
	| "root"
	| "product"
	| "folder"
	| "page";

export interface PETreeNode {

	/* filesystem */

	id: string;

	name: string;

	slug: string;

	path: string;

	type: PENodeType;

	/* documentation */

	title?: string;

	description?: string;

	icon?: string;

	badge?: string;

	order?: number;

	hidden?: boolean;

	/* hierarchy */

	parent?: PETreeNode;

	children: PETreeNode[];

	/* navigation */

	previous?: PETreeNode;

	next?: PETreeNode;
}

/* -------------------------------------------------------------------------- */
/* Runtime State                                                              */
/* -------------------------------------------------------------------------- */

interface PEState {

	tree: PETreeNode | null;

	current: PETreeNode | null;

	expanded: Set<string>;

    search: string;

	selected?: string;
}

/* -------------------------------------------------------------------------- */
/* Initial State                                                              */
/* -------------------------------------------------------------------------- */

const INITIAL_STATE: PEState = {

	tree: null,

	current: null,

	expanded: new Set(),

	search: "",

	selected: undefined,
};

/* -------------------------------------------------------------------------- */
/* Discovery Context                                                          */
/* -------------------------------------------------------------------------- */

interface PEDiscoveryResult {

	root: PETreeNode;

	current: PETreeNode;

	breadcrumbs: PETreeNode[];

	siblings: PETreeNode[];

	children: PETreeNode[];

	previous?: PETreeNode;

	next?: PETreeNode;
}

/* -------------------------------------------------------------------------- */
/* Utility                                                                    */
/* -------------------------------------------------------------------------- */

function createNode(
	data: Partial<PETreeNode>,
): PETreeNode {

	return {

		id: crypto.randomUUID(),

		name: "",

		slug: "",

		path: "",

		type: "page",

		children: [],

		...data,
	};
}

/* -------------------------------------------------------------------------- */
/* Discovery Stub                                                             */
/* -------------------------------------------------------------------------- */

function discoverDocumentation(): PEDiscoveryResult {

	const root = createNode({

		type: "root",

		title: "Documentation",

		name: "Documentation",

		path: "/",
	});

	return {

		root,

		current: root,

		breadcrumbs: [root],

		siblings: [],

		children: [],

		previous: undefined,

		next: undefined,
	};
}

/* -------------------------------------------------------------------------- */
/* Component State                                                            */
/* -------------------------------------------------------------------------- */

const discovery = discoverDocumentation();

const state: PEState = {

	...INITIAL_STATE,

	tree: discovery.root,

	current: discovery.current,

	selected: discovery.current.id,

};

state.expanded.add(discovery.root.id);

finalizeTree(state.tree);

/* ========================================================================== */
/*                    Part 3 — Explorer Data Utilities                        */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/* Tree Walking                                                               */
/* -------------------------------------------------------------------------- */

function walkTree(
	node: PETreeNode,
	callback: (node: PETreeNode) => void,
) {
	callback(node);

	for (const child of node.children) {
		walkTree(child, callback);
	}
}

/* -------------------------------------------------------------------------- */
/* Flatten Tree                                                               */
/* -------------------------------------------------------------------------- */

function flattenTree(
	root: PETreeNode,
): PETreeNode[] {

	const nodes: PETreeNode[] = [];

	walkTree(root, (node) => {

		nodes.push(node);

	});

	return nodes;
}

/* -------------------------------------------------------------------------- */
/* Sort Children                                                              */
/* -------------------------------------------------------------------------- */

function sortChildren(
	node: PETreeNode,
) {

	node.children.sort((a, b) => {

		const ao = a.order ?? Number.MAX_SAFE_INTEGER;
		const bo = b.order ?? Number.MAX_SAFE_INTEGER;

		if (ao !== bo) {
			return ao - bo;
		}

		return (a.title ?? a.name).localeCompare(
			b.title ?? b.name,
		);

	});

	node.children.forEach(sortChildren);

}

/* -------------------------------------------------------------------------- */
/* Parent Links                                                               */
/* -------------------------------------------------------------------------- */

function assignParents(
	node: PETreeNode,
	parent?: PETreeNode,
) {

	node.parent = parent;

	node.children.forEach((child) => {

		assignParents(child, node);

	});

}

/* -------------------------------------------------------------------------- */
/* Previous / Next Links                                                      */
/* -------------------------------------------------------------------------- */

function assignLinearNavigation(
	root: PETreeNode,
) {

	const pages = flattenTree(root).filter(
		(node) =>
			node.type === "page",
	);

	for (let i = 0; i < pages.length; i++) {

		pages[i].previous = pages[i - 1];

		pages[i].next = pages[i + 1];

	}

}

/* -------------------------------------------------------------------------- */
/* Breadcrumb Builder                                                         */
/* -------------------------------------------------------------------------- */

function buildBreadcrumbs(
	node: PETreeNode,
): PETreeNode[] {

	const result: PETreeNode[] = [];

	let current: PETreeNode | undefined = node;

	while (current) {

		result.unshift(current);

		current = current.parent;

	}

	return result;

}

/* -------------------------------------------------------------------------- */
/* Search                                                                     */
/* -------------------------------------------------------------------------- */

function searchTree(
	root: PETreeNode,
	query: string,
): PETreeNode[] {

	if (!query.trim()) {

		return flattenTree(root);

	}

	const lower = query.toLowerCase();

	return flattenTree(root).filter((node) => {

		return (

			node.title
				?.toLowerCase()
				.includes(lower)

			||

			node.name
				.toLowerCase()
				.includes(lower)

			||

			node.description
				?.toLowerCase()
				.includes(lower)

		);

	});

}

/* -------------------------------------------------------------------------- */
/* Expand Path                                                                */
/* -------------------------------------------------------------------------- */

function expandParents(
	node: PETreeNode,
	expanded: Set<string>,
) {

	let current = node.parent;

	while (current) {

		expanded.add(current.id);

		current = current.parent;

	}

}

/* -------------------------------------------------------------------------- */
/* Finalize Tree                                                              */
/* -------------------------------------------------------------------------- */

function finalizeTree(
	root: PETreeNode,
) {

	assignParents(root);

	sortChildren(root);

	assignLinearNavigation(root);

}

/* ========================================================================== */
/* End Part 3                                                                 */
/* ========================================================================== */

/* ========================================================================== */
/*                    Part 4 — Explorer Rendering Engine                      */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/* Icons                                                                      */
/* -------------------------------------------------------------------------- */

function nodeIcon(
	node: PETreeNode,
) {

	if (node.icon) {
		return node.icon;
	}

	switch (node.type) {

		case "root":
			return "🏠";

		case "product":
			return "📦";

		case "folder":
			return "📁";

		default:
			return "📄";

	}

}

/* -------------------------------------------------------------------------- */
/* Node Label                                                                 */
/* -------------------------------------------------------------------------- */

function nodeLabel(
	node: PETreeNode,
) {

	return node.title ??
		node.name ??
		"Untitled";

}

/* -------------------------------------------------------------------------- */
/* Explorer Node                                                              */
/* -------------------------------------------------------------------------- */

interface ExplorerNodeProps {

	node: PETreeNode;

	depth: number;

	state: PEState;

}

function ExplorerNode({

	node,

	depth,

	state,

}: ExplorerNodeProps) {

	const expanded =
		state.expanded.has(node.id);

	const hasChildren =
		node.children.length > 0;

	const selected =
		state.selected === node.id;

	const padding =
		depth * 18;

	return (

		<div>

			<button

				type="button"

				className={[
					"pe-node",

					selected &&
						"selected",
				]
					.filter(Boolean)
					.join(" ")}

				style={{
					paddingLeft:
						`${padding}px`,
				}}
			>

				<span
					className="pe-arrow"
				>

					{hasChildren
						? expanded
							? "▼"
							: "▶"
						: ""}

				</span>

				<span
					className="pe-icon"
				>

					{nodeIcon(node)}

				</span>

				<span
					className="pe-title"
				>

					{nodeLabel(node)}

				</span>

				{node.badge && (

					<span
						className="pe-badge"
					>

						{node.badge}

					</span>

				)}

			</button>

			{expanded &&
				hasChildren &&

				node.children.map(

					(child) => (

						<ExplorerNode

							key={child.id}

							node={child}

							depth={
								depth + 1
							}

							state={state}

						/>

					),

				)}

		</div>

	);

}

/* -------------------------------------------------------------------------- */
/* Explorer Panel                                                             */
/* -------------------------------------------------------------------------- */

function ExplorerPane() {

	if (!state.tree) {

		return null;

	}

	return (

		<aside
			className="pe-explorer"
		>

			<div className="pe-sidebar-header">

				<h3>
					Documentation
				</h3>

			</div>

			<div className="pe-sidebar-body">

				<ExplorerNode

					node={state.tree}

					depth={0}

					state={state}

				/>

			</div>

		</aside>

	);

}

/* -------------------------------------------------------------------------- */
/* Explorer Styles                                                            */
/* -------------------------------------------------------------------------- */

const explorerStyle = `

.pe-sidebar-header{

	padding-bottom:1rem;

	border-bottom:
	1px solid rgba(255,255,255,.06);

	margin-bottom:1rem;

}

.pe-sidebar-body{

	display:flex;

	flex-direction:column;

	gap:2px;

}

.pe-node{

	width:100%;

	display:flex;

	align-items:center;

	gap:.65rem;

	padding:.7rem .8rem;

	border:none;

	background:transparent;

	color:inherit;

	cursor:pointer;

	border-radius:12px;

	transition:.22s;

	font-size:.93rem;

	text-align:left;

}

.pe-node:hover{

	background:
	rgba(255,255,255,.045);

}

.pe-node.selected{

	background:
	rgba(59,130,246,.14);

	border:
	1px solid rgba(96,165,250,.25);

}

.pe-arrow{

	width:14px;

	opacity:.55;

}

.pe-icon{

	width:20px;

	text-align:center;

}

.pe-title{

	flex:1;

	overflow:hidden;

	text-overflow:ellipsis;

	white-space:nowrap;

}

.pe-badge{

	font-size:.68rem;

	padding:.15rem .45rem;

	border-radius:999px;

	background:
	rgba(96,165,250,.16);

	color:#60a5fa;

	font-weight:700;

}

`;

if (
	typeof document !==
	"undefined"
) {

	if (
		!document.getElementById(
			"pe-explorer-style",
		)
	) {

		const css =
			document.createElement(
				"style",
			);

		css.id =
			"pe-explorer-style";

		css.innerHTML =
			explorerStyle;

		document.head.appendChild(
			css,
		);

	}

}

/* ========================================================================== */
/* End Part 4                                                                 */
/* ========================================================================== */

/* ========================================================================== */
/*                  Part 5 — Breadcrumb Navigation System                     */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/* Breadcrumb Types                                                           */
/* -------------------------------------------------------------------------- */

interface BreadcrumbItemProps {

	node: PETreeNode;

	active?: boolean;

}

/* -------------------------------------------------------------------------- */
/* Breadcrumb Item                                                            */
/* -------------------------------------------------------------------------- */

function BreadcrumbItem({

	node,

	active = false,

}: BreadcrumbItemProps) {

	return (

		<button

			type="button"

			className={[
				"pe-breadcrumb-item",

				active &&
					"active",

			]
				.filter(Boolean)
				.join(" ")}

		>

			<span>

				{nodeIcon(node)}

			</span>

			<span>

				{nodeLabel(node)}

			</span>

		</button>

	);

}

/* -------------------------------------------------------------------------- */
/* Breadcrumb Divider                                                         */
/* -------------------------------------------------------------------------- */

function BreadcrumbDivider() {

	return (

		<button

			type="button"

			className="pe-breadcrumb-divider"

			title="Show siblings"

		>

			▶

		</button>

	);

}

/* -------------------------------------------------------------------------- */
/* Breadcrumb Bar                                                             */
/* -------------------------------------------------------------------------- */

function BreadcrumbBar() {

	if (!state.current) {

		return null;

	}

	const breadcrumbs =
		buildBreadcrumbs(
			state.current,
		);

	return (

		<nav
			className="pe-breadcrumbs"
		>

			{breadcrumbs.map(

				(node, index) => (

					<React.Fragment
						key={node.id}
					>

						<BreadcrumbItem

							node={node}

							active={
								index ===
								breadcrumbs.length -
									1
							}

						/>

						{index <
							breadcrumbs.length -
								1 && (

							<BreadcrumbDivider />

						)}

					</React.Fragment>

				),

			)}

		</nav>

	);

}

/* -------------------------------------------------------------------------- */
/* Update Header                                                              */
/* -------------------------------------------------------------------------- */


/* -------------------------------------------------------------------------- */
/* Breadcrumb Styles                                                          */
/* -------------------------------------------------------------------------- */

const breadcrumbStyle = `

.pe-breadcrumbs{

	display:flex;

	align-items:center;

	flex-wrap:wrap;

	gap:.45rem;

	margin-bottom:2rem;

	font-size:.9rem;

}

.pe-breadcrumb-item{

	display:flex;

	align-items:center;

	gap:.55rem;

	padding:.45rem .75rem;

	border:none;

	border-radius:999px;

	cursor:pointer;

	background:transparent;

	color:rgba(255,255,255,.65);

	transition:.22s;

}

.pe-breadcrumb-item:hover{

	background:
	rgba(255,255,255,.05);

	color:white;

}

.pe-breadcrumb-item.active{

	background:
	rgba(59,130,246,.14);

	color:#60a5fa;

	font-weight:700;

}

.pe-breadcrumb-divider{

	width:28px;

	height:28px;

	border:none;

	border-radius:999px;

	background:transparent;

	cursor:pointer;

	color:
	rgba(255,255,255,.35);

	transition:.2s;

}

.pe-breadcrumb-divider:hover{

	background:
	rgba(255,255,255,.05);

	color:#60a5fa;

}

.pe-header-content{

	display:flex;

	flex-direction:column;

	gap:.9rem;

}

.pe-header-content h1{

	font-size:

	clamp(
		2.3rem,
		5vw,
		4rem
	);

	font-weight:900;

	line-height:1.05;

}

.pe-header-content p{

	max-width:900px;

	font-size:1.05rem;

	line-height:1.8;

	color:
	rgba(255,255,255,.64);

}

`;

if (
	typeof document !==
	"undefined"
) {

	if (
		!document.getElementById(
			"pe-breadcrumb-style",
		)
	) {

		const style =
			document.createElement(
				"style",
			);

		style.id =
			"pe-breadcrumb-style";

		style.innerHTML =
			breadcrumbStyle;

		document.head.appendChild(
			style,
		);

	}

}

/* ========================================================================== */
/* End Part 5                                                                 */
/* ========================================================================== */

/* ========================================================================== */
/*                 Part 6 — Documentation Header (Metadata)                   */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/* Header Metadata                                                            */
/* -------------------------------------------------------------------------- */

interface HeaderMetadataProps {

	meta?: ProductExplorerMetadata;

}

function HeaderMetadata({

	meta,

}: HeaderMetadataProps) {

	if (!meta) {

		return null;

	}

	return (

		<div className="pe-meta">

			{/* ------------------------------------------------------ */}
			{/* Avatar                                                  */}
			{/* ------------------------------------------------------ */}

			{meta.author?.avatar && (

				<img

					className="pe-avatar"

					src={meta.author.avatar}

					alt={meta.author.name}

				/>

			)}

			{/* ------------------------------------------------------ */}
			{/* Information                                             */}
			{/* ------------------------------------------------------ */}

			<div className="pe-meta-info">

				{meta.author && (

					<div className="pe-meta-row">

						<span className="pe-meta-label">

							Author

						</span>

						<span>

							{meta.author.name}

						</span>

					</div>

				)}

				{meta.version && (

					<div className="pe-meta-row">

						<span className="pe-meta-label">

							Version

						</span>

						<span>

							{meta.version}

						</span>

					</div>

				)}

				{meta.status && (

					<div className="pe-meta-row">

						<span className="pe-meta-label">

							Status

						</span>

						<span
							className={`pe-status ${meta.status}`}
						>

							{meta.status}

						</span>

					</div>

				)}

				{meta.updated && (

					<div className="pe-meta-row">

						<span className="pe-meta-label">

							Updated

						</span>

						<span>

							{meta.updated}

						</span>

					</div>

				)}

			</div>

		</div>

	);

}

/* -------------------------------------------------------------------------- */
/* Replace HeaderPane                                                         */
/* -------------------------------------------------------------------------- */

function HeaderPane({

	title,

	description,

	meta,

}: {

	title?: string;

	description?: string;

	meta?: ProductExplorerMetadata;

}) {

	return (

		<header className="pe-header">

			<BreadcrumbBar />

			<div className="pe-header-content">

				<h1>

					{title}

				</h1>

				{description && (

					<p>

						{description}

					</p>

				)}

				<HeaderMetadata

					meta={meta}

				/>

			</div>

		</header>

	);

}

/* -------------------------------------------------------------------------- */
/* Update Main Component                                                      */
/* -------------------------------------------------------------------------- */

/*

Replace

<HeaderPane
	title={settings.title}
	description={settings.description}
/>

with

<HeaderPane
	title={settings.title}
	description={settings.description}
	meta={settings.metadata}
/>

*/

/* -------------------------------------------------------------------------- */
/* Add to ProductExplorerProps                                                */
/* -------------------------------------------------------------------------- */

/*

metadata?: ProductExplorerMetadata;

*/

/* -------------------------------------------------------------------------- */
/* Metadata Styles                                                            */
/* -------------------------------------------------------------------------- */

const metadataStyle = `

.pe-meta{

	margin-top:2rem;

	display:flex;

	align-items:flex-start;

	gap:1.5rem;

	padding:1.5rem;

	border-radius:20px;

	border:
	1px solid rgba(255,255,255,.06);

	background:
	rgba(255,255,255,.02);

	backdrop-filter:blur(14px);

}

.pe-avatar{

	width:72px;

	height:72px;

	border-radius:999px;

	object-fit:cover;

	border:
	2px solid rgba(255,255,255,.08);

}

.pe-meta-info{

	display:flex;

	flex-wrap:wrap;

	column-gap:2rem;

	row-gap:.85rem;

	flex:1;

}

.pe-meta-row{

	display:flex;

	align-items:center;

	gap:.65rem;

	font-size:.92rem;

}

.pe-meta-label{

	color:
	rgba(255,255,255,.45);

	font-weight:600;

}

.pe-status{

	padding:.22rem .6rem;

	border-radius:999px;

	font-size:.78rem;

	font-weight:700;

	text-transform:capitalize;

}

.pe-status.stable{

	background:
	rgba(52,211,153,.15);

	color:#34d399;

}

.pe-status.beta{

	background:
	rgba(96,165,250,.15);

	color:#60a5fa;

}

.pe-status.alpha{

	background:
	rgba(251,191,36,.15);

	color:#fbbf24;

}

.pe-status.deprecated{

	background:
	rgba(239,68,68,.15);

	color:#ef4444;

}

@media(max-width:900px){

	.pe-meta{

		flex-direction:column;

	}

}

`;

if (
	typeof document !==
	"undefined"
) {

	if (
		!document.getElementById(
			"pe-meta-style",
		)
	) {

		const style =
			document.createElement(
				"style",
			);

		style.id =
			"pe-meta-style";

		style.innerHTML =
			metadataStyle;

		document.head.appendChild(
			style,
		);

	}

}

/* ========================================================================== */
/* End Part 6                                                                 */
/* ========================================================================== */

