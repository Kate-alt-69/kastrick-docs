"use client";

import { createPage, defineSchema } from "#module/engine";

/* -------------------------------------------------------------------------- */
/*                             HERO FOUNDATION V2                             */
/* -------------------------------------------------------------------------- */

const HeroSection = {
	type: "hero",
	key: "hero",

	props: {
		variant: "centered",

		fullViewport: true,

		parallax: true,

		contentMaxWidth: "1600px",

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
			xl: "8rem",
		},

		py: {
			xs: "8rem",
			md: "9rem",
			lg: "11rem",
		},

		bg: `
			radial-gradient(circle at 50% -15%,
				rgba(96,165,250,.22),
				transparent 30%),

			radial-gradient(circle at 0% 100%,
				rgba(168,85,247,.16),
				transparent 40%),

			radial-gradient(circle at 100% 0%,
				rgba(34,197,94,.12),
				transparent 35%),

			linear-gradient(
				180deg,
				#04070d 0%,
				#07101b 45%,
				#091522 100%
			)
		`,

		color: "#fff",

		style: {
			position: "relative",

			overflow: "hidden",

			minHeight: "100vh",

			isolation: "isolate",

			backgroundImage: `
				linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
				linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px)
			`,

			backgroundSize: "52px 52px",

			maskImage:
				"linear-gradient(to bottom, black 85%, transparent)",

			animation: "heroGridMove 18s linear infinite",

			"::before": {
				content: '""',

				position: "absolute",

				inset: "-30%",

				background: `
					conic-gradient(
						from 0deg,
						rgba(96,165,250,.18),
						rgba(168,85,247,.10),
						rgba(34,197,94,.10),
						rgba(96,165,250,.18)
					)
				`,

				filter: "blur(120px)",

				animation: "heroRotate 42s linear infinite",

				zIndex: -3,
			},

			"::after": {
				content: '""',

				position: "absolute",

				inset: 0,

				background: `
					radial-gradient(
						800px circle at var(--mouse-x,50%) var(--mouse-y,30%),
						rgba(255,255,255,.06),
						transparent 55%
					)
				`,

				pointerEvents: "none",

				zIndex: -2,
			},

			"@keyframes heroRotate": {
				from: {
					transform: "rotate(0deg) scale(1.2)",
				},

				to: {
					transform: "rotate(360deg) scale(1.2)",
				},
			},

			"@keyframes heroGridMove": {
				from: {
					backgroundPosition: "0 0,0 0",
				},

				to: {
					backgroundPosition: "52px 52px,52px 52px",
				},
			},
		},
	},
		children: [
			/* ------------------------------------------------------------------ */
			/* Decorative Background Layer                                        */
			/* ------------------------------------------------------------------ */
			/*
				Pure schema.
				No custom JS.
				Uses only engine-supported CSS props and cprop.
				EngineBrowser / EngineManim will be added later once those APIs are
				read completely.
			*/

			{
				type: "box",
			
				props: {
					position: "absolute",
					inset: 0,
					overflow: "hidden",
					pointerEvents: "none",
					zIndex: -1,
				},
			
				children: [
					{
						type: "box",
					
						props: {
							position: "absolute",
							top: "-12%",
							left: "-6%",
						
							width: "34rem",
							height: "34rem",
						
							borderRadius: "999px",
						
							background:
								"radial-gradient(circle, rgba(59,130,246,.20) 0%, transparent 72%)",
						
							filter: "blur(70px)",
						
							animation:
								"floatY 12s ease-in-out infinite",
						},
					},
				
					{
						type: "box",
					
						props: {
							position: "absolute",
						
							right: "-10%",
							top: "20%",
						
							width: "28rem",
							height: "28rem",
						
							borderRadius: "999px",
						
							background:
								"radial-gradient(circle, rgba(168,85,247,.16) 0%, transparent 72%)",
						
							filter: "blur(70px)",
						
							animation:
								"floatX 16s ease-in-out infinite",
						},
					},
				
					{
						type: "box",
					
						props: {
							position: "absolute",
						
							left: "35%",
							bottom: "-12%",
						
							width: "24rem",
							height: "24rem",
						
							borderRadius: "999px",
						
							background:
								"radial-gradient(circle, rgba(34,197,94,.14) 0%, transparent 72%)",
						
							filter: "blur(65px)",
						
							animation:
								"floatY 18s ease-in-out infinite reverse",
						},
					},
				
					{
						type: "box",
					
						props: {
							position: "absolute",
						
							inset: 0,
						
							backgroundImage: `
								linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px),
								linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px)
							`,
						
							backgroundSize: {
								xs: "26px 26px",
								md: "34px 34px",
								lg: "44px 44px",
							},
						
							maskImage:
								"radial-gradient(circle at center, black 30%, transparent 95%)",
						
							opacity: .45,
						},
					},
				],
			},

			/* ------------------------------------------------------------------ */
			/* Floating Status Badge                                               */
			/* ------------------------------------------------------------------ */

			{
				type: "card",

				props: {
					variant: "filled",

					borderRadius: "999px",

					bg: "rgba(255,255,255,.045)",

					border: "1px solid rgba(255,255,255,.08)",

					backdropFilter: "blur(24px)",

					innerPadding: ".55rem .95rem",

					style: {
						width: "fit-content",

						marginInline: "auto",

						marginBottom: "2rem",

						boxShadow:
							"0 0 40px rgba(96,165,250,.15)",
					},

					cprop: {
						onHover: {
							transform: "translateY(-2px) scale(1.02)",
							borderColor: "rgba(96,165,250,.4)",
						},
					},
				},

				children: [
					{
						type: "stack",

						props: {
							direction: "horizontal",

							align: "center",

							gap: ".75rem",
						},

						children: [
							{
								type: "badge",

								props: {
									label: "LIVE",

									variant: "filled",

									style: {
										background: "#22c55e",
										color: "#06120a",
										fontWeight: 800,
									},
								},
							},

							{
								type: "text",

								props: {
									content:
										"Powered by the Nextjs Engine",

									fontWeight: 700,

									color: "rgba(255,255,255,.85)",
								},
							},
						],
					},
				],
			},

			/* ------------------------------------------------------------------ */
			/* Eyebrow                                                            */
			/* ------------------------------------------------------------------ */

			{
				type: "text",

				props: {
					variant: "overline",

					content:
						"OFFICIAL DOCUMENTATION • OPEN SOURCE • NEXTJS ENGINE",

					color: "#7dd3fc",

					fontWeight: 800,

					letterSpacing: ".25em",

					mb: "1.5rem",

					style: {
						textTransform: "uppercase",

						opacity: .92,

						animation:
							"fadeInUp .8s ease forwards",
					},
				},
			},

			/* ------------------------------------------------------------------ */
			/* Main Heading                                                       */
			/* ------------------------------------------------------------------ */

			{
				type: "heading",

				props: {
					level: 1,

					content: "Kastrick",

					fontWeight: 950,

					lineHeight: .86,

					align: "center",

					fontSize: {
						xs: "clamp(4.2rem,14vw,5.5rem)",
						md: "clamp(6rem,9vw,8rem)",
						lg: "clamp(7rem,8vw,10rem)",
					},

					gradient: `
						linear-gradient(
							180deg,
							#ffffff 0%,
							#e2e8f0 35%,
							#93c5fd 75%,
							#60a5fa 100%
						)
					`,

					mb: "1.75rem",

					style: {
						textShadow:
							"0 10px 60px rgba(96,165,250,.28)",

						animation:
							"heroTitle 1s cubic-bezier(.2,.9,.2,1) forwards",
					},
				},
			},

			/* ------------------------------------------------------------------ */
			/* Subtitle                                                           */
			/* ------------------------------------------------------------------ */

			{
				type: "text",

				props: {
					variant: "lead",

					content:
						"One ecosystem. One documentation platform. Explore every engine, API, backend service, package and project through a unified, schema-driven experience.",

					maxWidth: "900px",

					align: "center",

					color: "rgba(255,255,255,.72)",

					lineHeight: 1.85,

					fontSize: {
						xs: "1.1rem",
						md: "1.22rem",
						lg: "1.3rem",
					},

					mb: "3rem",

					style: {
						animation:
							"fadeInUp 1s ease .15s forwards",

						opacity: 0,
					},
				},
			},

		/* ------------------------------------------------------------------ */
		/* Primary Actions                                                    */
		/* ------------------------------------------------------------------ */

		{
			type: "stack",

			props: {
				direction: "horizontal",

				justify: "center",

				align: "center",

				wrap: true,

				gap: "1rem",

				mb: "3.5rem",

				style: {
					animation: "fadeInUp 1s ease .3s forwards",
					opacity: 0,
				},
			},

			children: [
				{
					type: "button",

					props: {
						label: "Explore Documentation",

						variant: "elevated",

						size: "xl",

						href: "/product/nextjs-engine",

						style: {
							minWidth: "230px",

							height: "58px",

							fontWeight: 800,

							borderRadius: "999px",

							background: `
								linear-gradient(
									135deg,
									#3b82f6,
									#60a5fa
								)
							`,

							boxShadow:
								"0 20px 60px rgba(59,130,246,.35)",
						},

						cprop: {
							link: {
								transition: "instant",
							},

							onHover: {
								transform:
									"translateY(-4px) scale(1.03)",

								boxShadow:
									"0 30px 80px rgba(59,130,246,.45)",
							},
						},
					},
				},

				{
					type: "button",

					props: {
						label: "Browse Products",

						variant: "outline",

						size: "xl",

						href: "/product",

						style: {
							minWidth: "190px",

							height: "58px",

							borderRadius: "999px",

							border:
								"1px solid rgba(255,255,255,.12)",

							backdropFilter: "blur(18px)",

							background:
								"rgba(255,255,255,.03)",
						},

						cprop: {
							onHover: {
								background:
									"rgba(255,255,255,.06)",

								borderColor:
									"rgba(96,165,250,.45)",

								transform:
									"translateY(-4px)",
							},
						},
					},
				},

				{
					type: "button",

					props: {
						label: "GitHub",

						variant: "ghost",

						size: "xl",

						href: "https://github.com/Kate-alt-69/kastrick",

						style: {
							height: "58px",

							borderRadius: "999px",
						},
					},
				},
			],
		},

		/* ------------------------------------------------------------------ */
		/* Quick Stats                                                       */
		/* ------------------------------------------------------------------ */

		{
			type: "grid",

			props: {
				columns: {
					xs: 2,
					md: 4,
				},

				gap: "1.25rem",

				style: {
					maxWidth: "1100px",

					marginInline: "auto",

					marginBottom: "5rem",

					animation:
						"fadeInUp 1s ease .45s forwards",

					opacity: 0,
				},
			},

			children: [
				{
					label: "Framework",
					value: "Nextjs Engine",
					color: "#60a5fa",
				},
				{
					label: "Projects",
					value: "04",
					color: "#22c55e",
				},
				{
					label: "Status",
					value: "Stable",
					color: "#34d399",
				},
				{
					label: "License",
					value: "MIT",
					color: "#fbbf24",
				},
			].map((item) => ({
				type: "card",

				props: {
					variant: "filled",

					interactive: true,

					borderRadius: "24px",

					bg: `
						linear-gradient(
							180deg,
							rgba(255,255,255,.045),
							rgba(255,255,255,.02)
						)
					`,

					border:
						"1px solid rgba(255,255,255,.07)",

					backdropFilter: "blur(18px)",

					innerPadding: "1.5rem",

					cprop: {
						onHover: {
							transform:
								"translateY(-6px)",

							borderColor:
								`${item.color}55`,
						},
					},
				},

				children: [
					{
						type: "text",

						props: {
							content: item.label,

							color:
								"rgba(255,255,255,.5)",

							fontWeight: 700,

							mb: ".5rem",
						},
					},

					{
						type: "heading",

						props: {
							level: 4,

							content: item.value,

							style: {
								color: item.color,
							},
						},
					},
				],
			})),
		},
			
		/* ------------------------------------------------------------------ */
		/* Floating Project Preview (UPGRADE)                                 */
		/* Replace the current preview card with this design.                 */
		/* ------------------------------------------------------------------ */
			
		{
			type: "card",
		
			props: {
				variant: "filled",
			
				borderRadius: "30px",
			
				border: "1px solid rgba(255,255,255,.08)",
			
				bg: `
					linear-gradient(
						180deg,
						rgba(255,255,255,.045),
						rgba(255,255,255,.015)
					)
				`,
			
				backdropFilter: "blur(22px)",
			
				interactive: true,
			
				innerPadding: "2rem",
			
				style: {
					maxWidth: "1180px",
				
					marginInline: "auto",
				
					overflow: "hidden",
				
					position: "relative",
				
					animation: "fadeInUp 1s ease .45s forwards",
				
					opacity: 0,
				},
			
				cprop: {
					onHover: {
						transform: "translateY(-8px)",
					
						boxShadow:
							"0 35px 100px rgba(0,0,0,.35)",
					
						borderColor:
							"rgba(96,165,250,.35)",
					},
				},
			},
		
			children: [
			
				/* ------------------------------------------------------------ */
				/* Header                                                       */
				/* ------------------------------------------------------------ */
			
				{
					type: "grid",
				
					props: {
						columns: {
							xs: 1,
							lg: "1fr auto",
						},
					
						align: "center",
					
						gap: "2rem",
					
						mb: "2rem",
					},
				
					children: [
					
						{
							type: "stack",
						
							props: {
								gap: ".65rem",
							},
						
							children: [
							
								{
									type: "badge",
								
									props: {
										label: "FEATURED PROJECT",
									
										variant: "filled",
									},
								},
							
								{
									type: "heading",
								
									props: {
										level: 3,
									
										content:
											"Nextjs Engine",
									
										fontSize: {
											xs: "2rem",
											lg: "2.5rem",
										},
									},
								},
							
								{
									type: "text",
								
									props: {
										content:
											"The schema-driven React framework powering the entire Kastrick ecosystem.",
									
										color:
											"rgba(255,255,255,.68)",
									
										lineHeight: 1.8,
									},
								},
							],
						},
					
						{
							type: "button",
						
							props: {
								label: "Open Docs",
							
								size: "lg",
							
								variant: "outline",
							
								href: "/product/nextjs-engine",
							},
						},
					],
				},
			
				/* ------------------------------------------------------------ */
				/* Dashboard                                                    */
				/* ------------------------------------------------------------ */
			
				{
					type: "grid",
				
					props: {
						columns: {
							xs: 1,
							lg: "360px 1fr",
						},
					
						gap: "2rem",
					},
				
					children: [
					
						/* ------------------------------------------------------ */
						/* Left Navigation                                         */
						/* ------------------------------------------------------ */
					
						{
							type: "card",
						
							props: {
								variant: "filled",
							
								borderRadius: "22px",
							
								bg: "rgba(255,255,255,.03)",
							
								border:
									"1px solid rgba(255,255,255,.05)",
							
								innerPadding: "1.5rem",
							},
						
							children: [
							
								...[
									"Getting Started",
									"Components",
									"Layouts",
									"Markdown",
									"EngineAPIResolver",
									"EngineManim",
									"EngineBrowser",
									"Examples",
								].map((item) => ({
								
									type: "text",
								
									props: {
									
										content: item,
									
										mb: ".65rem",
									
										style: {
											padding: ".85rem 1rem",
										
											borderRadius: "12px",
										
											cursor: "pointer",
										
											transition:
												".25s",
										
											background:
												item ===
												"EngineManim"
													? "rgba(96,165,250,.12)"
													: "transparent",
										},
									},
								
								})),
							
							],
						},
					
						/* ------------------------------------------------------ */
						/* Preview Window                                          */
						/* ------------------------------------------------------ */
					
						{
							type: "card",
						
							props: {
								variant: "filled",
							
								borderRadius: "22px",
							
								bg:
									"rgba(255,255,255,.025)",
							
								border:
									"1px solid rgba(255,255,255,.05)",
							
								innerPadding: "1.75rem",
							},
						
							children: [
							
								{
									type: "stack",
								
									props: {
										direction: "horizontal",
									
										gap: ".45rem",
									
										mb: "1.5rem",
									},
								
									children: [
									
										"#ef4444",
										"#f59e0b",
										"#22c55e",
									
									].map((c) => ({
									
										type: "box",
									
										props: {
											width: "12px",
										
											height: "12px",
										
											borderRadius:
												"999px",
										
											bg: c,
										},
									})),
								},
							
								{
									type: "heading",
								
									props: {
										level: 4,
									
										content:
											"EngineManim",
									
										mb: "1rem",
									},
								},
							
								{
									type: "text",
								
									props: {
										content:
											"Build mathematical animations directly from your schema. Timelines, transforms, SVG paths, camera movements and educational graphics are all rendered through the engine.",
									
										lineHeight: 1.9,
									
										color:
											"rgba(255,255,255,.66)",
									
										mb: "2rem",
									},
								},
							
								{
									type: "badge",
								
									props: {
										label:
											"Interactive Preview",
									
										variant: "outline",
									},
								},
							],
						},
					],
				},
			],
		},
		/* ------------------------------------------------------------------ */
		/* Animated Scroll Indicator (Replace existing one)                   */
		/* ------------------------------------------------------------------ */

		{
			type: "stack",
		
			props: {
				align: "center",
			
				gap: ".75rem",
			
				mt: "5rem",
			
				style: {
					animation:
						"fadeInUp 1s ease .8s forwards",
				
					opacity: 0,
				},
			},
		
			children: [
				{
					type: "text",
				
					props: {
						content: "Explore the Engine",
					
						fontWeight: 700,
					
						color: "rgba(255,255,255,.55)",
					
						letterSpacing: ".08em",
					},
				},
			
				{
					type: "box",
				
					props: {
						width: "34px",
					
						height: "58px",
					
						borderRadius: "999px",
					
						border:
							"2px solid rgba(255,255,255,.18)",
					
						position: "relative",
					
						style: {
							overflow: "hidden",
						},
					},
				
					children: [
						{
							type: "box",
						
							props: {
								position: "absolute",
							
								left: "50%",
							
								top: "8px",
							
								width: "6px",
							
								height: "12px",
							
								borderRadius: "999px",
							
								bg: "#60a5fa",
							
								style: {
									transform:
										"translateX(-50%)",
								
									animation:
										"scrollMouse 1.8s infinite",
								},
							},
						},
					],
				},
			],
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                         PRODUCT EXPLORER SECTION                           */
/* -------------------------------------------------------------------------- */

const ProductExplorerSection = {
	type: "section",
	key: "products",

	props: {
		py: {
			xs: "5rem",
			md: "7rem",
			lg: "8rem",
		},

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
		},

		contentMaxWidth: "1500px",

		bg: "#090f19",

		style: {
			position: "relative",

			borderTop: "1px solid rgba(255,255,255,.05)",

			borderBottom: "1px solid rgba(255,255,255,.05)",
		},
	},

	children: [
		{
			type: "stack",

			props: {
				align: "center",
				gap: ".9rem",
				mb: "5rem",
			},

			children: [
				{
					type: "text",

					props: {
						variant: "overline",

						content: "EXPLORE",

						color: "#60a5fa",

						letterSpacing: ".18em",

						fontWeight: 700,
					},
				},

				{
					type: "heading",

					props: {
						level: 2,

						content: "Everything Kastrick.",

						fontWeight: 900,

						fontSize: {
							xs: "2.4rem",
							md: "3rem",
							lg: "3.6rem",
						},

						align: "center",
					},
				},

				{
					type: "text",

					props: {
						content:
							"Documentation, products, APIs and resources—organized into dedicated sections so you can jump directly where you need to be.",

						maxWidth: "760px",

						align: "center",

						color: "rgba(255,255,255,.62)",

						lineHeight: 1.8,
					},
				},
			],
		},

		{
			type: "grid",

			props: {
				columns: {
					xs: 1,
					md: 2,
					xl: 4,
				},

				gap: "2rem",
			},

			children: [
				/* ======================================================= */

				{
					type: "card",

					props: {
						variant: "filled",

						borderRadius: "28px",

						border: "1px solid rgba(255,255,255,.06)",

						bg: `
							linear-gradient(
								180deg,
								rgba(96,165,250,.08),
								rgba(255,255,255,.02)
							)
						`,

						interactive: true,

						innerPadding: "2rem",

						cprop: {
							link: {
								href: "/product/nextjs-engine",
								transition: "instant",
							},

							onHover: {
								transform: "translateY(-8px)",
								borderColor: "rgba(96,165,250,.4)",
							},
						},
					},

					children: [
						{
							type: "text",

							props: {
								content: "FRAMEWORK",
								color: "#60a5fa",
								fontWeight: 700,
								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 3,

								content: "Nextjs Engine",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Schema-driven rendering, responsive layouts, API resolvers, markdown, animation, SSR utilities and everything that powers this website.",

								color: "rgba(255,255,255,.65)",

								lineHeight: 1.8,

								mb: "2rem",
							},
						},

						{
							type: "text",

							props: {
								content: "Browse Documentation →",

								color: "#60a5fa",

								fontWeight: 700,
							},
						},
					],
				},

				/* ======================================================= */

				{
					type: "card",

					props: {
						variant: "filled",

						borderRadius: "28px",

						border: "1px solid rgba(255,255,255,.06)",

						bg: `
							linear-gradient(
								180deg,
								rgba(52,211,153,.08),
								rgba(255,255,255,.02)
							)
						`,

						interactive: true,

						innerPadding: "2rem",

						cprop: {
							link: {
								href: "/product/backend",
							},
						},
					},

					children: [
						{
							type: "text",

							props: {
								content: "SERVER",

								color: "#34d399",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 3,

								content: "Back-End",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Authentication, APIs, infrastructure, EngineAPIResolver endpoints, networking, deployment and backend architecture.",

								lineHeight: 1.8,

								color: "rgba(255,255,255,.65)",

								mb: "2rem",
							},
						},

						{
							type: "text",

							props: {
								content: "Explore Services →",

								color: "#34d399",

								fontWeight: 700,
							},
						},
					],
				},

				/* ======================================================= */

				{
					type: "card",

					props: {
						variant: "filled",

						borderRadius: "28px",

						border: "1px solid rgba(255,255,255,.06)",

						bg: `
							linear-gradient(
								180deg,
								rgba(244,114,182,.08),
								rgba(255,255,255,.02)
							)
						`,

						interactive: true,

						innerPadding: "2rem",

						cprop: {
							link: {
								href: "/docs",
							},
						},
					},

					children: [
						{
							type: "text",

							props: {
								content: "GUIDES",

								color: "#f472b6",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 3,

								content: "Documentation",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Step-by-step guides, examples, API references, migration notes and architecture documentation.",

								lineHeight: 1.8,

								color: "rgba(255,255,255,.65)",

								mb: "2rem",
							},
						},

						{
							type: "text",

							props: {
								content: "Start Reading →",

								color: "#f472b6",

								fontWeight: 700,
							},
						},
					],
				},

				/* ======================================================= */

				{
					type: "card",

					props: {
						variant: "filled",

						borderRadius: "28px",

						border: "1px solid rgba(255,255,255,.06)",

						bg: `
							linear-gradient(
								180deg,
								rgba(251,191,36,.08),
								rgba(255,255,255,.02)
							)
						`,

						interactive: true,

						innerPadding: "2rem",

						cprop: {
							link: {
								href: "/credit",
							},
						},
					},

					children: [
						{
							type: "text",

							props: {
								content: "OPEN SOURCE",

								color: "#fbbf24",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 3,

								content: "Credits",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Contributors, licenses, acknowledgements, open-source dependencies and technologies powering Kastrick.",

								lineHeight: 1.8,

								color: "rgba(255,255,255,.65)",

								mb: "2rem",
							},
						},

						{
							type: "text",

							props: {
								content: "View Credits →",

								color: "#fbbf24",

								fontWeight: 700,
							},
						},
					],
				},
			],
		},
	],
};

const WhyKastrickSection = {
	type: "section",
	key: "why-kastrick",

	props: {
		bg: "#070b12",

		contentMaxWidth: "1500px",

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
		},

		py: {
			xs: "5rem",
			md: "7rem",
			lg: "8rem",
		},
	},

	children: [
		{
			type: "grid",

			props: {
				columns: {
					xs: 1,
					lg: "420px 1fr",
				},

				gap: "4rem",

				align: "center",
			},

			children: [
				/* ======================================================= */
				/* LEFT                                                     */
				/* ======================================================= */

				{
					type: "stack",

					props: {
						gap: "1.5rem",
					},

					children: [
						{
							type: "text",

							props: {
								variant: "overline",

								content: "WHY KASTRICK",

								color: "#60a5fa",

								fontWeight: 700,

								letterSpacing: ".18em",
							},
						},

						{
							type: "heading",

							props: {
								level: 2,

								content:
									"Built to document itself.",

								fontWeight: 900,

								fontSize: {
									xs: "2.2rem",
									md: "2.8rem",
									lg: "3.4rem",
								},
							},
						},

						{
							type: "text",

							props: {
								content:
									"This documentation isn't a separate frontend. It is built using the Nextjs Engine itself. Every section, interaction and layout demonstrates the same components you'll use in your own applications.",

								color: "rgba(255,255,255,.68)",

								lineHeight: 1.9,
							},
						},
					],
				},

				/* ======================================================= */
				/* RIGHT                                                    */
				/* ======================================================= */

				{
					type: "grid",

					props: {
						columns: {
							xs: 1,
							md: 2,
						},

						gap: "1.5rem",
					},

					children: [
						{
							type: "card",

							props: {
								variant: "filled",

								interactive: true,

								borderRadius: "22px",

								innerPadding: "1.75rem",

								border:
									"1px solid rgba(255,255,255,.06)",
							},

							children: [
								{
									type: "heading",

									props: {
										level: 4,

										content: "⚡ Schema Driven",

										mb: ".9rem",
									},
								},

								{
									type: "text",

									props: {
										content:
											"Describe pages instead of manually building repetitive layouts.",

										color:
											"rgba(255,255,255,.60)",

										lineHeight: 1.75,
									},
								},
							],
						},

						{
							type: "card",

							props: {
								variant: "filled",

								interactive: true,

								borderRadius: "22px",

								innerPadding: "1.75rem",

								border:
									"1px solid rgba(255,255,255,.06)",
							},

							children: [
								{
									type: "heading",

									props: {
										level: 4,

										content: "📱 Responsive",

										mb: ".9rem",
									},
								},

								{
									type: "text",

									props: {
										content:
											"Built-in responsive props eliminate most custom media-query boilerplate.",

										color:
											"rgba(255,255,255,.60)",

										lineHeight: 1.75,
									},
								},
							],
						},

						{
							type: "card",

							props: {
								variant: "filled",

								interactive: true,

								borderRadius: "22px",

								innerPadding: "1.75rem",

								border:
									"1px solid rgba(255,255,255,.06)",
							},

							children: [
								{
									type: "heading",

									props: {
										level: 4,

										content:
											"🧩 Component Ecosystem",

										mb: ".9rem",
									},
								},

								{
									type: "text",

									props: {
										content:
											"Cards, heroes, markdown, navigation, APIs and layouts all work together through one schema.",

										color:
											"rgba(255,255,255,.60)",

										lineHeight: 1.75,
									},
								},
							],
						},

						{
							type: "card",

							props: {
								variant: "filled",

								interactive: true,

								borderRadius: "22px",

								innerPadding: "1.75rem",

								border:
									"1px solid rgba(255,255,255,.06)",
							},

							children: [
								{
									type: "heading",

									props: {
										level: 4,

										content:
											"🚀 Performance First",

										mb: ".9rem",
									},
								},

								{
									type: "text",

									props: {
										content:
											"CSS tiering, rendering optimizations and lightweight output are built directly into the engine.",

										color:
											"rgba(255,255,255,.60)",

										lineHeight: 1.75,
									},
								},
							],
						},
					],
				},
			],
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                         LIVE PROJECT STATUS                                */
/*        (Later powered by EngineAPIResolver + GitHub REST API)              */
/* -------------------------------------------------------------------------- */

const LiveProjectSection = {
	type: "section",
	key: "live-status",

	props: {
		bg: "#070b12",

		contentMaxWidth: "1550px",

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
		},

		py: {
			xs: "5rem",
			md: "6rem",
			lg: "7rem",
		},
	},

	children: [
		{
			type: "stack",

			props: {
				align: "center",
				gap: "1rem",

				mb: "4rem",
			},

			children: [
				{
					type: "text",

					props: {
						variant: "overline",

						content: "LIVE PROJECT",

						color: "#60a5fa",

						fontWeight: 700,

						letterSpacing: ".18em",
					},
				},

				{
					type: "heading",

					props: {
						level: 2,

						content: "Project Pulse.",

						fontWeight: 900,

						fontSize: {
							xs: "2.5rem",
							md: "3rem",
							lg: "3.8rem",
						},
					},
				},

				{
					type: "text",

					props: {
						content:
							"This section is automatically populated using EngineAPIResolver. Repository information, releases, commits and contributor data stay synchronized with GitHub.",

						maxWidth: "850px",

						align: "center",

						color: "rgba(255,255,255,.65)",

						lineHeight: 1.85,
					},
				},
			],
		},

		{
			type: "grid",

			props: {
				columns: {
					xs: 1,
					md: 2,
					xl: 4,
				},

				gap: "1.5rem",
			},

			children: [
				/* ------------------------------------------------------- */

				{
					type: "card",

					props: {
						variant: "filled",

						interactive: true,

						borderRadius: "24px",

						innerPadding: "2rem",

						border:
							"1px solid rgba(255,255,255,.06)",

						bg: `
							linear-gradient(
								180deg,
								rgba(34,197,94,.10),
								rgba(255,255,255,.015)
							)
						`,
					},

					children: [
						{
							type: "text",

							props: {
								content: "Repository",

								color: "#22c55e",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 4,

								content: "Kate-alt-69/Kastrick",

								mb: "1.25rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Connected",

								color: "#34d399",

								fontWeight: 700,
							},
						},
					],
				},

				/* ------------------------------------------------------- */

				{
					type: "card",

					props: {
						variant: "filled",

						interactive: true,

						borderRadius: "24px",

						innerPadding: "2rem",

						border:
							"1px solid rgba(255,255,255,.06)",
					},

					children: [
						{
							type: "text",

							props: {
								content: "Latest Commit",

								color: "#60a5fa",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 4,

								content: "--",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Waiting for APIResolver",

								color: "rgba(255,255,255,.55)",
							},
						},
					],
				},

				/* ------------------------------------------------------- */

				{
					type: "card",

					props: {
						variant: "filled",

						interactive: true,

						borderRadius: "24px",

						innerPadding: "2rem",

						border:
							"1px solid rgba(255,255,255,.06)",
					},

					children: [
						{
							type: "text",

							props: {
								content: "Latest Release",

								color: "#a78bfa",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 4,

								content: "--",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Automatically updated",

								color:
									"rgba(255,255,255,.55)",
							},
						},
					],
				},

				/* ------------------------------------------------------- */

				{
					type: "card",

					props: {
						variant: "filled",

						interactive: true,

						borderRadius: "24px",

						innerPadding: "2rem",

						border:
							"1px solid rgba(255,255,255,.06)",
					},

					children: [
						{
							type: "text",

							props: {
								content: "Documentation",

								color: "#f59e0b",

								fontWeight: 700,

								mb: ".75rem",
							},
						},

						{
							type: "heading",

							props: {
								level: 4,

								content: "-- Pages",

								mb: "1rem",
							},
						},

						{
							type: "text",

							props: {
								content:
									"Generated automatically",

								color:
									"rgba(255,255,255,.55)",
							},
						},
					],
				},
			],
		},

		/* ============================================================= */

		{
			type: "card",

			props: {
				variant: "filled",

				borderRadius: "28px",

				mt: "2rem",

				border:
					"1px solid rgba(255,255,255,.06)",

				bg: "rgba(255,255,255,.015)",

				innerPadding: "2rem",
			},

			children: [
				{
					type: "grid",

					props: {
						columns: {
							xs: 1,
							lg: "220px 1fr",
						},

						gap: "2rem",

						align: "center",
					},

					children: [
						{
							type: "stack",

							props: {
								gap: ".5rem",
							},

							children: [
								{
									type: "heading",

									props: {
										level: 4,

										content:
											"Activity Feed",
									},
								},

								{
									type: "text",

									props: {
										content:
											"Recent repository events",

										color:
											"rgba(255,255,255,.55)",
									},
								},
							],
						},

						{
							type: "stack",

							props: {
								gap: ".85rem",
							},

							children: [
								{
									type: "text",

									props: {
										content:
											"● Waiting for GitHub API connection",

										color:
											"rgba(255,255,255,.70)",
									},
								},

								{
									type: "text",

									props: {
										content:
											"● Latest commit will appear here",

										color:
											"rgba(255,255,255,.55)",
									},
								},

								{
									type: "text",

									props: {
										content:
											"● Releases, issues and discussions are updated automatically",

										color:
											"rgba(255,255,255,.55)",
									},
								},
							],
						},
					],
				},
			],
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                           DOCUMENTATION HUB                                */
/* -------------------------------------------------------------------------- */

const DocumentationHubSection = {
	type: "section",
	key: "documentation",

	props: {
		bg: "#09111b",

		contentMaxWidth: "1550px",

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
		},

		py: {
			xs: "6rem",
			md: "7rem",
			lg: "8rem",
		},
	},

	children: [
		{
			type: "stack",

			props: {
				align: "center",

				gap: "1rem",

				mb: "4rem",
			},

			children: [
				{
					type: "text",

					props: {
						variant: "overline",

						content: "DOCUMENTATION",

						color: "#60a5fa",

						fontWeight: 700,

						letterSpacing: ".18em",
					},
				},

				{
					type: "heading",

					props: {
						level: 2,

						content:
							"Find exactly what you need.",

						fontWeight: 900,

						fontSize: {
							xs: "2.5rem",
							md: "3rem",
							lg: "3.8rem",
						},
					},
				},
			],
		},

		{
			type: "grid",

			props: {
				columns: {
					xs: 1,
					md: 2,
					lg: 3,
				},

				gap: "1.5rem",
			},

			children: [
				"Getting Started",
				"Components",
				"Layouts",
				"Markdown",
				"API Resolver",
				"Networking",
				"Animation",
				"Theme System",
				"Examples",
			].map((title) => ({
				type: "card",

				props: {
					variant: "filled",

					borderRadius: "22px",

					interactive: true,

					innerPadding: "1.8rem",

					border:
						"1px solid rgba(255,255,255,.06)",
				},

				children: [
					{
						type: "heading",

						props: {
							level: 4,

							content: title,

							mb: ".75rem",
						},
					},

					{
						type: "text",

						props: {
							content:
								"Browse documentation, guides, references and practical examples.",

							color:
								"rgba(255,255,255,.60)",

							lineHeight: 1.75,
						},
					},
				],
			})),
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                      LATEST UPDATES / CHANGELOG                            */
/* -------------------------------------------------------------------------- */

const LatestUpdatesSection = {
	type: "section",
	key: "latest-updates",

	props: {
		bg: "#070b12",

		contentMaxWidth: "1550px",

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
		},

		py: {
			xs: "5rem",
			md: "6rem",
			lg: "7rem",
		},
	},

	children: [
		{
			type: "grid",

			props: {
				columns: {
					xs: 1,
					lg: "380px 1fr",
				},

				gap: "3rem",

				align: "start",
			},

			children: [
				/* ====================================================== */

				{
					type: "stack",

					props: {
						gap: "1rem",
					},

					children: [
						{
							type: "text",

							props: {
								variant: "overline",

								content: "LATEST",

								color: "#60a5fa",

								fontWeight: 700,

								letterSpacing: ".18em",
							},
						},

						{
							type: "heading",

							props: {
								level: 2,

								content: "Recent Changes",

								fontWeight: 900,

								fontSize: {
									xs: "2.2rem",
									md: "2.8rem",
								},
							},
						},

						{
							type: "text",

							props: {
								content:
									"Automatically generated from GitHub releases, commits and documentation updates.",

								lineHeight: 1.8,

								color: "rgba(255,255,255,.65)",
							},
						},
					],
				},

				/* ====================================================== */

				{
					type: "stack",

					props: {
						gap: "1rem",
					},

					children: [
						...Array.from({ length: 5 }).map((_, i) => ({
							type: "card",

							props: {
								variant: "filled",

								borderRadius: "18px",

								interactive: true,

								border:
									"1px solid rgba(255,255,255,.05)",

								innerPadding: "1.5rem",
							},

							children: [
								{
									type: "grid",

									props: {
										columns: {
											xs: 1,
											md: "150px 1fr auto",
										},

										align: "center",

										gap: "1rem",
									},

									children: [
										{
											type: "text",

											props: {
												content: "Coming Soon",

												color: "#34d399",

												fontWeight: 700,
											},
										},

										{
											type: "text",

											props: {
												content:
													"GitHub commits, releases and documentation edits will appear here.",

												color:
													"rgba(255,255,255,.70)",
											},
										},

										{
											type: "text",

											props: {
												content: "--",

												color:
													"rgba(255,255,255,.40)",
											},
										},
									],
								},
							],
						})),
					],
				},
			],
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                           DOC SEARCH PREVIEW                               */
/* -------------------------------------------------------------------------- */

const SearchPreviewSection = {
	type: "section",

	key: "search",

	props: {
		bg: "#08101b",

		contentMaxWidth: "1550px",

		px: {
			xs: "1.5rem",
			md: "3rem",
			lg: "6rem",
		},

		py: {
			xs: "5rem",
			md: "6rem",
		},
	},

	children: [
		{
			type: "card",

			props: {
				variant: "filled",

				borderRadius: "28px",

				border:
					"1px solid rgba(255,255,255,.06)",

				bg: `
					linear-gradient(
						180deg,
						rgba(96,165,250,.05),
						rgba(255,255,255,.02)
					)
				`,

				innerPadding: "3rem",
			},

			children: [
				{
					type: "stack",

					props: {
						align: "center",

						gap: "1rem",

						mb: "2.5rem",
					},

					children: [
						{
							type: "heading",

							props: {
								level: 2,

								content:
									"Search Everything",

								fontWeight: 900,
							},
						},

						{
							type: "text",

							props: {
								content:
									"Search documentation, API references, guides, examples, releases and components.",

								align: "center",

								maxWidth: "760px",

								color:
									"rgba(255,255,255,.65)",
							},
						},
					],
				},

				{
					type: "input",

					props: {
						placeholder:
							"Search the Kastrick documentation...",

						size: "xl",

						style: {
							maxWidth: "900px",

							marginInline: "auto",
						},
					},
				},

				{
					type: "stack",

					props: {
						direction: "horizontal",

						wrap: true,

						gap: ".75rem",

						justify: "center",

						mt: "2rem",
					},

					children: [
						"API",
						"Card",
						"Hero",
						"Grid",
						"Layout",
						"Markdown",
						"Theme",
						"Animation",
						"EngineAPIResolver",
						"Routing",
					].map((tag) => ({
						type: "badge",

						props: {
							label: tag,

							variant: "filled",
						},
					})),
				},
			],
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                     CALL TO ACTION BEFORE FOOTER                           */
/* -------------------------------------------------------------------------- */

const BottomCTASection = {
	type: "section",

	key: "bottom-cta",

	props: {
		bg: "#070b12",

		contentMaxWidth: "1400px",

		centered: true,

		px: {
			xs: "1.5rem",
			md: "3rem",
		},

		py: {
			xs: "6rem",
			md: "8rem",
		},
	},

	children: [
		{
			type: "stack",

			props: {
				align: "center",

				gap: "1.5rem",
			},

			children: [
				{
					type: "heading",

					props: {
						level: 2,

						content:
							"Start building with Kastrick.",

						fontWeight: 900,

						fontSize: {
							xs: "2.5rem",
							md: "3.8rem",
						},
					},
				},

				{
					type: "text",

					props: {
						content:
							"Learn the engine, browse the APIs and explore every component powering this documentation.",

						maxWidth: "760px",

						align: "center",

						color:
							"rgba(255,255,255,.65)",

						lineHeight: 1.85,
					},
				},

				{
					type: "stack",

					props: {
						direction: "horizontal",

						gap: "1rem",

						wrap: true,

						justify: "center",

						mt: "1rem",
					},

					children: [
						{
							type: "button",

							props: {
								label:
									"Browse Documentation",

								variant: "elevated",

								size: "xl",

								href: "/docs",
							},
						},

						{
							type: "button",

							props: {
								label:
									"View Products",

								variant: "outline",

								size: "xl",

								href: "/product",
							},
						},

						{
							type: "button",

							props: {
								label:
									"GitHub",

								variant: "ghost",

								size: "xl",

								href: "https://github.com/Kate-alt-69/kastrick",
							},
						},
					],
				},
			],
		},
	],
};

/* -------------------------------------------------------------------------- */
/*                        FEATURE STRIP                                        */
/* -------------------------------------------------------------------------- */

const FeatureStripSection = {
	type: "section",

	key: "feature-strip",

	props: {
		bg: "#0a1018",

		px: {
			xs: "1rem",
			md: "3rem",
			lg: "6rem",
		},

		py: "2rem",

		contentMaxWidth: "1600px",

		borderTop: "1px solid rgba(255,255,255,.05)",

		borderBottom: "1px solid rgba(255,255,255,.05)",
	},

	children: [
		{
			type: "stack",

			props: {
				direction: "horizontal",

				wrap: true,

				gap: ".8rem",

				justify: "center",
			},

			children: [
				"SSR Ready",
				"Static Generation",
				"Responsive",
				"Markdown",
				"EngineAPIResolver",
				"Animations",
				"Theme Variables",
				"View Transitions",
				"Accessibility",
				"Performance Optimized",
				"Zero Boilerplate",
				"Type Safe",
			].map((feature) => ({
				type: "badge",

				props: {
					label: feature,

					variant: "outline",

					style: {
						paddingInline: "1rem",

						paddingBlock: ".55rem",

						borderRadius: "999px",

						border:
							"1px solid rgba(255,255,255,.08)",

						background:
							"rgba(255,255,255,.025)",

						fontWeight: 600,
					},
				},
			})),
		},
	],
};

const HomeSchema = defineSchema({
	meta: {
		title: "Kastrick Documentation",
		description:
			"The official documentation hub for the Kastrick ecosystem.",
	},

	theme: {
		vars: {
			"--e-bg": "#070b12",
			"--e-bg-light": "#101826",

			"--e-card-bg": "#101826",

			"--e-divider": "rgba(255,255,255,.08)",

			"--e-primary": "#ffffff",

			"--e-secondary": "#60a5fa",

			"--e-success": "#34d399",

			"--e-muted": "#94a3b8",
		},

		fonts: [
			"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap",
		],

		globalStyles: `
			*{
				box-sizing:border-box;
				margin:0;
				padding:0;
			}

			html{
				scroll-behavior:smooth;
			}

			body{
				background:var(--e-bg);
				color:white;
				font-family:Inter,sans-serif;
				-webkit-font-smoothing:antialiased;
				text-rendering:optimizeLegibility;
				overflow-x:hidden;
			}

			/* ===================================================== */
			/* HERO ANIMATIONS                                       */
			/* ===================================================== */

			@keyframes fadeInUp{
				from{
					opacity:0;
					transform:translateY(32px);
				}
				to{
					opacity:1;
					transform:translateY(0);
				}
			}

			@keyframes heroTitle{
				from{
					opacity:0;
					transform:translateY(40px) scale(.96);
					filter:blur(12px);
				}
				to{
					opacity:1;
					transform:translateY(0) scale(1);
					filter:blur(0);
				}
			}

			@keyframes heroBounce{
				0%,100%{
					transform:translateY(0);
				}

				50%{
					transform:translateY(12px);
				}
			}

			@keyframes heroGlow{
				0%,100%{
					filter:blur(80px);
					opacity:.45;
				}

				50%{
					filter:blur(120px);
					opacity:.85;
				}
			}

			@keyframes floatY{
				0%,100%{
					transform:translateY(0px);
				}

				50%{
					transform:translateY(-18px);
				}
			}

			@keyframes floatX{
				0%,100%{
					transform:translateX(0px);
				}

				50%{
					transform:translateX(22px);
				}
			}

			@keyframes pulseBorder{
				0%,100%{
					box-shadow:
						0 0 0 rgba(96,165,250,0),
						0 0 0 rgba(96,165,250,0);
				}

				50%{
					box-shadow:
						0 0 20px rgba(96,165,250,.22),
						0 0 60px rgba(96,165,250,.15);
				}
			}
			@keyframes scrollMouse{

				0%{
					transform:
						translate(-50%,0);
				
					opacity:0;
				}
				
				25%{
					opacity:1;
				}
				
				70%{
					transform:
						translate(-50%,22px);
				
					opacity:1;
				}
				
				100%{
					transform:
						translate(-50%,28px);
				
					opacity:0;
				}
			}
				
			@keyframes floatX{
				
				0%{
					transform:translateX(0px);
				}
				
				50%{
					transform:translateX(45px);
				}
				
				100%{
					transform:translateX(0px);
				}
			}
				
			@keyframes floatY{
				
				0%{
					transform:translateY(0px);
				}
				
				50%{
					transform:translateY(-35px);
				}
				
				100%{
					transform:translateY(0px);
				}
			}
				
			@keyframes fadeInUp{
				
				from{
					opacity:0;
					transform:
						translateY(40px);
				}
				
				to{
					opacity:1;
					transform:
						translateY(0);
				}
			}

			/* ===================================================== */
			/* FLOATING ORBS                                         */
			/* ===================================================== */

			.hero-orb{
				position:absolute;
				border-radius:999px;
				filter:blur(90px);
				pointer-events:none;
				z-index:-2;
				animation:heroGlow 8s ease-in-out infinite;
			}

			.hero-orb.one{
				width:340px;
				height:340px;
				top:8%;
				left:-60px;
				background:#3b82f6;
				opacity:.16;
			}

			.hero-orb.two{
				width:420px;
				height:420px;
				right:-120px;
				top:24%;
				background:#8b5cf6;
				opacity:.14;
				animation-delay:2s;
			}

			.hero-orb.three{
				width:280px;
				height:280px;
				left:35%;
				bottom:-80px;
				background:#22c55e;
				opacity:.12;
				animation-delay:4s;
			}

			/* ===================================================== */

			::selection{
				background:#60a5fa;
				color:white;
			}
			`,
	},


	root: {
		type: "stack",

		props: {
			direction: "vertical",
			bg: "var(--e-bg)",
		},

		children: [
			HeroSection,
		
			ProductExplorerSection,
		
			WhyKastrickSection,
		
			FeatureStripSection,
		
			LiveProjectSection,
		
			DocumentationHubSection,
		
			LatestUpdatesSection,
		
			SearchPreviewSection,
		
			BottomCTASection,
		],
	},
});

export default createPage(HomeSchema);